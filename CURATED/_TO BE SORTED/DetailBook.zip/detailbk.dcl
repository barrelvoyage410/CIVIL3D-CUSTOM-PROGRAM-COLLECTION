//   DETAIL.DCL
//   Detail Book
//
//   Written by Luke Livermore
//   (C) Copyright 1999 by Design Point
//   All rights reserved
//
//   This program and all associated data files are copyrighted and the property
//   of Design Point and is licensed only under the following conditions.
//   You may use this program and all associated files in it's
//   current form only.  Any changes to this program must be made through Design
//   Point.  Under federal copyright laws, publishing or copying in whole or any
//   part of this program from any and all associated files in any form must be
//   requested in writing prior to copying or publishing and be accompanied by
//   proper acknowledgment to it's author.
//
// This file to be used in conjuction with DETAILBK.LSP




dbk_detail_book : dialog {
   label = "Detail Book";
   : column {
      : column {
         fixed_width = true;
         alignment   = centered;
         : text {
            alignment = left;
            label     = "Select a Category";
         }
         : popup_list {
            key       = dbk_categories;
            alignment = left;
            width     = 30;
         }
      }
      : boxed_column {
         : row {
            : list_box {
               key       = dbk_blocknames;
               label     = "Select a block";
               alignment = left;
               width     = 24;
               allow_accept = true;
            }
            : column {
               : boxed_row {
                  : text {
                     key   = dbk_slidename;
                     label = "";
                     alignment = left;
                  }
               }
               fixed_width = true;
               : image {
                  key    = dbk_slideimage;
                  width  = 70;
                  aspect_ratio = 0.6667;
                  color  = 0;
               }
               : boxed_row {
                  : text {
                     key   = dbk_description;
                     label = "";
                     alignment = left;
                  }
               }
            }
         }
      }
      : boxed_row {
         label = "Options";
         children_alignment = centered;
         children_fixed_height = true;
         fixed_width = true;
         alignment = centered;
         : toggle {
            label    = "Drag rotation";
            key      = dbk_rotate;
            mnemonic = "D";
            value    = "1";
         }
         : toggle {
            label    = "Explode";
            key      = dbk_explode;
            mnemonic = "p";
         }
         : toggle {
            label    = "Multiple Insert";
            key      = dbk_multiple;
            mnemonic = "M";
         }
         : edit_box {
            label    = "Scale factor";
            width    = 8;
            key      = dbke_scale;
         }
      }
      errtile;
      spacer_1;
      insert_add_edit_cancel;
   }
}
dbk_make_book : dialog {
   label = "Add to Detail Book";
   initial_focus = "category_name";
   : boxed_row {
      : column {
         : text { label = "Category Name"; height = 1.5; alignment = right;}
         : text { label = "Block Name";    height = 1.5; alignment = right;}
         : text { label = "Slide Name";    height = 1.5; alignment = right;}
         : text { label = "Description";   height = 1.5; alignment = right;}
         spacer_1;
      }
      : column {
         : edit_box {
            key        = "category_name";
            width      = 30;
            edit_limit = 64;
         }
         : edit_box {
            key        = "block_name";
            width      = 30;
            edit_limit = 32;
         }
         : edit_box {
            key        = "slide_name";
            width      = 30;
            edit_limit = 32;
         }
         : edit_box {
            key        = "description";
            width      = 30;
            edit_limit = 64;
         }
         spacer_1;
      }
      : column {
         : popup_list {
            key       = dbk_categories;
            alignment = left;
            width     = 30;
            is_tab_stop = false;
         }
         browse_button;
         spacer_1;
         spacer_1;
         spacer_1;
         spacer_1;
      }
   }
   errtile;
   add_recall_exit;
}
dbk_edit_book : dialog {
   label = "Edit the Detail Book";
   : column {
      fixed_width = true;
      alignment   = centered;
      : text {
         alignment = left;
         label     = "Select a Category";
      }
      : popup_list {
         key       = dbk_categories;
         alignment = left;
         width     = 30;
      }
   }
   : boxed_column {
      : row {
         : column {
            : list_box {
               key       = dbk_blocknames;
               label     = "Select a block name to edit";
               alignment = left;
               width     = 24;
               height    = 10;
            }
            up_down_delete;
         }
         : column {
            : text { label = "Block Name";    height = 1.25; alignment = right;}
            : text { label = "Slide Name";    height = 1.25; alignment = right;}
            : text { label = "Description";   height = 1.25; alignment = right;}
            : text {height = 12;}
         }
         : column {
            children_fixed_height = true;
            children_fixed_width = true;
            : edit_box {
               key        = "block_name";
               width      = 30;
               edit_limit = 32;
               is_enabled = false;
            }
            : edit_box {
               key        = "slide_name";
               width      = 30;
               edit_limit = 32;
               is_enabled = false;
            }
            : edit_box {
               key        = "description";
               width      = 30;
               edit_limit = 64;
               is_enabled = false;
            }
            spacer_1;
            update_button;
            : text {height = 8;}
         }
      }
   }
   errtile;
   ok_cancel;
}
move_up_button : button {
   label      = "  Move Up  ";
   key        = "dbk_move_up";
   mnemonic   = "U";
   fixed_width = true;
   alignment = centered;
   is_enabled = false;
}
move_down_button : button {
   label      = "Move Down";
   key        = "dbk_move_down";
   mnemonic   = "D";
   fixed_width = true;
   alignment = centered;
   is_enabled = false;
}
update_button : button {
   label      = "Update";
   key        = "dbk_update";
   mnemonic   = "U";
   is_enabled = false;
   alignment  = centered;
}
delete_button : button {
   label      = "Delete";
   key        = "dbk_delete";
   mnemonic   = "D";
   is_enabled = false;
}
insert_button : retirement_button {
   label      = "  Insert  ";
   key        = "dbk_insert";
   is_default = true;
   mnemonic   = "I";
}
add_detail_button : button {
   label      = "Add Detail";
   key        = "dbk_add";
   mnemonic   = "A";
}
edit_detail_button : button {
   label      = "Edit Detail";
   key        = "dbk_edit";
   mnemonic   = "E";
}
add_to_list_button : button {
   label      = "Add to list";
   key        = "dbk_add";
   mnemonic   = "A";
}
recall_button : button {
   label      = "  Recall   ";
   key        = "dbk_recall";
   mnemonic   = "R";
   is_enabled = false;
}
browse_button : button {
   label      = "  Browse  ";
   key        = "dbk_browse";
   mnemonic   = "B";
   fixed_width = true;
}
about_button : button {
   label      = "  About   ";
   key        = "dbk_about";
   mnemonic   = "b";
}
dbk_cancel_button : retirement_button {
   label      = "   Exit   ";
   key        = "cancel";
   is_cancel  = true;
   mnemonic   = "x";
}
up_down_delete : column {
   : column {
      fixed_width = true;
      alignment   = centered;
      move_up_button;
      move_down_button;
      delete_button;
   }
}
add_recall_exit : column {
   : row {
      fixed_width = true;
      alignment   = centered;
      add_to_list_button;
      spacer_1;
      recall_button;
      spacer_1;
      dbk_cancel_button;
   }
}
insert_add_edit_cancel : column {
   : row {
      fixed_width = true;
      alignment   = centered;
      insert_button;
      spacer_1;
      add_detail_button;
      spacer_1;
      edit_detail_button;
      spacer_1;
      dbk_cancel_button;
      spacer_1;
      about_button;
   }
}
dbk_about : dialog {
   label = "About Detail Book";
   : boxed_row {
      : paragraph {
         : text_part {
            alignment   = centered;
            label       = "Detail Book (tm)";
         }
         : text_part {
            alignment   = centered;
            label       = "Version 4.5";
         }
         spacer_1;
         : text_part {
            alignment   = centered;
            label       = "Written by Luke Livermore";
         }
         : text_part {
            alignment   = centered;
            label       = "(c) Copyright Design Point 1999";
         }
         : text_part {
            alignment   = centered;
            label       = "All Rights Reserved";
            is_cancel = true;
         }
         spacer_1;
         : text_part {
            alignment   = centered;
            label       = "Visit our web site at";
            is_cancel = true;
         }
         : text_part {
            alignment   = centered;
            label       = "http://www.designpt.com";
            is_cancel = true;
         }
         spacer_1;
         : text_part {
            alignment   = centered;
            label       = "Address comments to luke@designpt.com";
            is_cancel = true;
         }
         spacer_1;
      }
   }
   ok_only;
}

