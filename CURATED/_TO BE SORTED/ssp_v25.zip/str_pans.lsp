;;   STR_PAN.LSP   Version 2.5
;;
;;   (C) Copyright 1999 by Design Point
;;   All rights reserved
;;
;;   This program is copyrighted by Design Point and is licensed
;;   to you under the following conditions.  You may not distribute
;;   or publish the source code of this program in any form.
;;
;;   DESIGN POINT PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
;;   DESIGN POINT SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MER-
;;   CHANTABILITY OR FITNESS FOR A PARTICULAR USE.  DESIGN POINT
;;   DOES NOT WARRANT THAT THE OPERATION OF THIS OR PARTS OF THIS
;;   PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
;;

;; This file to be used in conjuction with STR_PANS.DCL

(defun ssp_about ()
   (new_dialog "ssp_about" SSP_DCL_FILE)
   (start_dialog)
)
(defun ssp_init (a) (setq SSP_DCL_FILE (load_dialog a)))

;;
;; The folowing functions are in support of square nosings
;;
(defun str_type_a_a (/ a b c d e f i l m n ad cp t1
                       d1 d2 p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12)
   (princ "\nDraw Riser Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_RISER_HEIGHT
         c SSP_PAN_FILL
         d SSP_STL_THICKNESS
         e (list (list 0 0.75 1.25) (list pi 0.25 1.75))
   )
   (foreach f e
      (setq p1 (polar a (+ (car f) pi) (+ d 0.75))
            p2 a
            p3 (polar p2 (* pi 1.5) (+ c d))
            p4 (polar p3 (+ (car f) pi) (- 1.0 d))
            p5 (polar p4 (* pi 1.5) (- b (distance p2 p3)))
            p6 (polar p5 (+ (car f) pi) (+ 1.0 d))
            p7 (polar p6 (* pi 0.5) d)
            p8 (polar p5 (* pi (cadr f)) (* d (sqrt 2.0)))
            p9 (polar p4 (* pi (cadr f)) (* d (sqrt 2.0)))
            p10 (polar p3 (* pi (cadr f)) (* d (sqrt 2.0)))
            p11 (polar p2 (* pi (caddr f)) (* d (sqrt 2.0)))
            p12 (polar p1 (* pi 1.5) d)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p1)
            )
         )
      )
      (setq cp (append cp (list p6 p7)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".undo" "g")
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 10 d1) pause ""
                         "ver" (nth 10 d1) (nth 9 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 9 d1) (nth 2 d1) a ""
                         "ver" (nth 2 d1) (nth 7 d1) a ""
                         "ver" (nth 1 d1) (nth 4 d1) pause ""
                         "hor" (nth 3 d1) (nth 9 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 9 d1) (nth 2 d1) a ""
                         "hor" (nth 7 d1) (nth 2 d1) pause ""
                         "hor" (nth 6 d1) (nth 7 d1) pause "" "exit")
         (setq a (+ (distance (nth 11 d1) (nth 10 d1))
                    (distance (nth 10 d1) (nth 9 d1))
                    (- (distance (nth 9 d1) (nth 8 d1)) d)
                    (- (distance (nth 3 d1) (nth 4 d1)) d)
                    (distance (nth 7 d1) (nth 6 d1))))
         (initget 1)
         (setq c (strcat "Total Stretch-out = " (rtos a)))
         (setq b (getpoint (strcat "\n[PICK] Text left justification point: <" c "> ")))
         (command ".text" b (* (getvar "dimscale") (getvar "dimtxt")) 0 c)
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)
(defun str_type_a_b (/ a b c d e f g l m n i ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12)
   (setq b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
   )
   (while (progn
             (princ "\nDraw Stair Pan Section.")
             (setq a (getpoint "\n[PICK] nosing point: "))
          )
      (setq ad nil cp nil)
      (setq f (list (list 0 0.75 pi 1.25) (list pi 0.25 0 1.75)))
      (foreach g f
         (setq p1 (polar a (caddr g) (+ 0.75 e))
               p2 a
               p3 (polar p2 (* pi 1.5) (+ d e))
               p4 (polar p3 (caddr g) (- 1.0 e))
               p5 (polar p4 (* pi 1.5) (- (+ c d) (distance p2 p3) e))
               p6 (polar p5 (car g) (- (+ b (distance p3 p4)) 0.5))
               p7 (polar p6 (* pi 1.5) e)
               p8 (polar p5 (* pi (cadddr g)) (* e (sqrt 2.0)))
               p9 (polar p4 (* pi (cadr g)) (* e (sqrt 2.0)))
               p10 (polar p3 (* pi (cadr g)) (* e (sqrt 2.0)))
               p11 (polar p2 (* pi (cadddr g)) (* e (sqrt 2.0)))
               p12 (polar p1 (* pi 1.5) e)
         )
         (setq ad
            (append ad
               (list
                  (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p1)
               )
            )
         )
         (setq cp (append cp (list p6 p7)))
      )
      (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
      (setq d1 (car ad) d2 (cadr ad) t1 d1)
      (grvecs d1)
      (princ "\n[DRAG] Pan direction and [PICK]: ")
      (grread 5)
      (while (/= 3 (car (setq l (grread 5))))
         (if (= 5 (car l))
            (progn
               (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
               (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
               (if (< n m)
                  (if (not (equal t1 d1))
                     (progn
                        (grvecs t1)
                        (grvecs d1)
                        (setq t1 d1)
                     )
                  )
                  (if (not (equal t1 d2))
                     (progn
                        (grvecs t1)
                        (grvecs d2)
                        (setq t1 d2)
                     )
                  )
               )
            )
         )
      )
      (grvecs t1)
      (setq d1 (list (cadr t1)) i 1)
      (foreach a t1
         (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
         (setq i (1+ i))
      )
      (setq m (getvar "blipmode"))
      (setvar "blipmode" 0)
      (command ".undo" "g")
      (command ".pline" (nth 0 d1) "w" 0 0)
         (foreach i (cdr d1) (command i))
         (command "c")
      (if (= SSP_AUTO_DIMS "1")
         (progn
            (princ "\n[DRAG] Dimension placement:")
            (command ".dim" "hor" (nth 0 d1) (nth 10 d1) pause ""
                            "ver" (nth 10 d1) (nth 9 d1) pause "")
                            (setq a (getvar "lastpoint"))
                            (command
                            "ver" (nth 9 d1) (nth 1 d1) a ""
                            "ver" (nth 9 d1) (nth 2 d1) a ""
                            "ver" (nth 2 d1) (nth 4 d1) a ""
                            "ver" (nth 1 d1) (nth 6 d1) pause ""
                            "hor" (nth 3 d1) (nth 9 d1) pause "")
                            (setq a (getvar "lastpoint"))
                            (command
                            "hor" (nth 9 d1) (nth 2 d1) a ""
                            "hor" (nth 2 d1) (nth 7 d1) pause ""
                            "hor" (nth 4 d1) (nth 6 d1) pause "" "exit")
            (setq a (+ (distance (nth 11 d1) (nth 10 d1))
                       (distance (nth 10 d1) (nth 9 d1))
                       (- (distance (nth 9 d1) (nth 8 d1)) e)
                       (distance (nth 3 d1) (nth 4 d1))
                       (distance (nth 4 d1) (nth 5 d1))))
            (initget 1)
            (setq c (strcat "Total Stretch-out = " (rtos a)))
            (setq f (getpoint (strcat "\n[PICK] Text left justification point: <" c "> ")))
            (command ".text" f (* (getvar "dimscale") (getvar "dimtxt")) 0 c)
         )
      )
      (if (= SSP_DRAW_FILL "1")
         (progn
            (setq p1 (polar (nth 4 d1) (* pi 0.5) (- d e))
                  p8 (nth 4 d1)
                  p2 (polar p1 (angle (nth 4 d1) (nth 5 d1)) (- (+ b (- 1.0 e)) (+ e 0.75)))
                  p3 (polar p2 (* pi 1.5) e)
                  p4 (polar p3 (angle p1 p2) 0.75)
                  p5 (polar p4 (* pi 1.5) (distance (nth 10 d1) (nth 9 d1)))
                  p6 (polar p5 (angle p2 p1) (- 0.5 e))
                  p7 (polar p6 (* pi 0.5) e)
            )
            (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 "c")
            (setq a (ssadd (entlast)))
            (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
         )
      )
      (setvar "blipmode" m)
      (command ".undo" "e")
   )
   (princ)
)
(defun str_type_a_c (/ a b c d e f g h i l m n ad cp d1 d2 t1 p1 p2 p3 p4 p5 p6)
   (princ "\nDraw Closing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list pi 0.75) (list 0 0.25))
   )
   (foreach h g
      (setq p1 (polar a (* pi 1.5) (- d e))
            p1 (polar p1 (car h) 0.5)
            p2 (polar p1 (* pi 1.5) e)
            p3 (polar p2 (car h) (- b 0.5))
            p4 (polar p3 (* pi 1.5) (- f d))
            p5 (polar p4 (car h) e)
            p6 (polar p3 (* pi (cadr h)) (* e (sqrt 2.0)))
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p1)
            )
         )
      )
      (setq cp (append cp (list p5 p6)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".undo" "g")
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 2 d1) pause ""
                         "ver" (nth 2 d1) (nth 4 d1) pause "" "exit")
         (setq a (+ (distance (nth 1 d1) (nth 2 d1))
                    (distance (nth 2 d1) (nth 3 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos a)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p1 (nth 0 d1)
               p2 (nth 1 d1)
               p8 (nth 5 d1)
               p3 (polar (nth 1 d1) (angle (nth 2 d1) (nth 1 d1)) (- 0.5 e))
               p4 (polar p3 (* pi 0.5) (- d e))
               p5 (polar p4 (angle (nth 1 d1) (nth 2 d1)) 0.75)
               p6 (polar p5 (* pi 0.5) e)
               p7 (polar p8 (* pi 0.5) (- d e))
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)
(defun str_type_a_d (/ a b c d e f g h i l m n ad cp d2 t2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14)
   (princ "\nDraw Landing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list 0 0.75 pi 1.25) (list pi 0.25 0 1.75))
   )
   (foreach h g
      (setq p1 (polar a (caddr h) (+ 0.75 e))
            p2 a
            p3 (polar p2 (* pi 1.5) (+ d e))
            p4 (polar p3 (caddr h) (- 1.0 e))
            p5 (polar p4 (* pi 1.5) (- (+ c d) (distance p2 p3) e))
            p6 (polar p5 (car h) (+ (distance p4 p3) b e))
            p7 (polar p6 (* pi 1.5) (+ e (- f d)))
            p8 (polar p7 (caddr h) e)
            p9 (polar p6 (* pi (cadddr h)) (* e (sqrt 2.0)))
            p10 (polar p5 (* pi (cadddr h)) (* e (sqrt 2.0)))
            p11 (polar p4 (* pi (cadr h)) (* e (sqrt 2.0)))
            p12 (polar p3 (* pi (cadr h)) (* e (sqrt 2.0)))
            p13 (polar p2 (* pi (cadddr h)) (* e (sqrt 2.0)))
            p14 (polar p1 (* pi 1.5) e)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p13 p13 p14 p14 p1)
            )
         )
      )
      (setq cp (append cp (list p6 p7)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".undo" "g")
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 12 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 12 d1) (nth 1 d1) a ""
                         "hor" (nth 1 d1) (nth 8 d1) a ""
                         "hor" (nth 8 d1) (nth 5 d1) a ""
                         "ver" (nth 6 d1) (nth 8 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 8 d1) (nth 5 d1) a ""
                         "ver" (nth 5 d1) (nth 2 d1) a ""
                         "ver" (nth 2 d1) (nth 11 d1) a ""
                         "ver" (nth 11 d1) (nth 12 d1) a ""
                         "ver" (nth 1 d1) (nth 6 d1) pause ""
                         "hor" (nth 3 d1) (nth 11 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 11 d1) (nth 2 d1) a ""
                         "hor" (nth 10 d1) (nth 2 d1) pause ""
                         "hor" (nth 7 d1) (nth 4 d1) pause "" "exit")
         (setq a (+ (distance (nth 13 d1) (nth 12 d1))
                    (distance (nth 12 d1) (nth 11 d1))
                    (- (distance (nth 11 d1) (nth 10 d1)) e)
                    (distance (nth 3 d1) (nth 4 d1))
                    (- (distance (nth 4 d1) (nth 5 d1)) e)
                    (distance (nth 8 d1) (nth 7 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos a)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h"> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p1 (polar (nth 4 d1) (* pi 0.5) (- d e))
               p2 (polar (nth 5 d1) (* pi 0.5) (- d e))
               p3 (nth 5 d1)
               p4 (nth 4 d1)
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)


;;
;; The folowing functions are in support of sloped nosings
;;
(defun str_type_b_a (/ a b c d e f i l m n ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12)
   (princ "\nDraw Riser Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_RISER_HEIGHT
         c SSP_PAN_FILL
         d SSP_STL_THICKNESS
         e (list (list 0 0.5 pi) (list pi 1.5 0))
   )
   (foreach f e
      (setq p1 (polar a (caddr f) (+ 0.75 d))
            p2 a
            p12 (polar p1 (* pi 1.5) d)
            p11 (polar p12 (car f) 0.75)
            p10 (polar p11 (* pi 1.5) 0.75)
            p9 (polar p2 (* pi 1.5) c)
            p9 (polar p9 (caddr f) 1.0)
            p8 (polar p9 (* pi 1.5) (- b c d))
            p7 (polar p8 (caddr f) 1.0)
            p6 (polar p7 (* pi 1.5) d)
            p5 (polar p6 (car f) (+ 1.0 d))
            p4 (polar p9 (+ (* pi (cadr f)) (angle p10 p9)) d)
            p3 (polar p10 (+ (* pi (cadr f)) (angle p10 p9)) d)
            p4 (inters p5 (polar p5 (* pi 0.5) 12) p4 p3 nil)
            p3 (inters p2 (polar p2 (* pi 1.5) 12) p4 p3 nil)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p1)
            )
         )
      )
      (setq cp (append cp (list p6 p7)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 10 d1) pause ""
                         "rot" (angtos (angle (nth 8 d1) (nth 9 d1)) 0 4) (nth 3 d1) (nth 9 d1) pause ""
                         "ver" (nth 10 d1) (nth 9 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 9 d1) (nth 3 d1) a ""
                         "ver" (nth 3 d1) (nth 7 d1) a ""
                         "ver" (nth 1 d1) (nth 4 d1) pause ""
                         "hor" (nth 3 d1) (nth 9 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 9 d1) (nth 2 d1) a ""
                         "hor" (nth 8 d1) (nth 2 d1) pause ""
                         "hor" (nth 5 d1) (nth 7 d1) pause "" "exit")
         (setq h (distance (nth 9 d1) (nth 2 d1)))
         (setq h (sqrt (- (* h h) (* d d))))
         (setq a (+ (distance (nth 11 d1) (nth 10 d1))
                    (distance (nth 10 d1) (nth 9 d1))
                    (- (distance (nth 2 d1) (nth 3 d1)) h)
                    (- (distance (nth 3 d1) (nth 4 d1)) d)
                    (distance (nth 6 d1) (nth 7 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos a)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (setvar "blipmode" m)
   (princ)
)
(defun str_type_b_b (/ a b c d e f g h i l m n p ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14)
   (setq b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
   )
   (while (progn
             (princ "\nDraw Stair Pan Section.")
             (setq a (getpoint "\n[PICK] nosing point: "))
          )
      (setq ad nil cp nil)
      (setq f (list (list 0 0.5 pi 1.25) (list pi 1.5 0 1.75)))
      (foreach g f
         (setq p1 (polar a (caddr g) (+ 0.75 e))
               p2 a
               p14 (polar p1 (* pi 1.5) e)
               p13 (polar p14 (car g) 0.75)
               p12 (polar p13 (* pi 1.5) 0.75)
               p11 (polar p2 (* pi 1.5) d)
               p11 (polar p11 (caddr g) 1.0)
               p10 (polar p11 (* pi 1.5) c)
               p9 (polar p10 (car g) b)
               p5 (polar p10 (angle p13 p2) (distance p13 p2))
               p4 (polar p11 (+ (* pi (cadr g)) (angle p12 p11)) e)
               p3 (polar p12 (+ (* pi (cadr g)) (angle p12 p11)) e)
               p4 (inters p5 (polar p5 (* pi 0.5) 12) p4 p3 nil)
               p3 (inters p2 (polar p2 (* pi 1.5) 12) p4 p3 nil)
               p6 (polar p9 (+ (angle p11 p12) (* pi (cadr g))) e)
               p7 (polar p6 (angle p11 p12) 0.75)
               p6 (inters p5 (polar p5 (car g) 12) p6 p7 nil)
               p7 (polar p6 (angle p11 p12) 0.75)
               p8 (polar p7 (+ (angle p12 p11) (* pi (cadr g))) e)
         )
         (setq ad
            (append ad
               (list
                  (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p13 p13 p14 p14 p1)
               )
            )
         )
         (setq cp (append cp (list p6 p7)))
      )
      (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
      (setq d1 (car ad) d2 (cadr ad) t1 d1)
      (grvecs d1)
      (princ "\n[DRAG] Pan direction and [PICK]: ")
      (grread 5)
      (while (/= 3 (car (setq l (grread 5))))
         (if (= 5 (car l))
            (progn
               (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
               (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
               (if (< n m)
                  (if (not (equal t1 d1))
                     (progn
                        (grvecs t1)
                        (grvecs d1)
                        (setq t1 d1)
                     )
                  )
                  (if (not (equal t1 d2))
                     (progn
                        (grvecs t1)
                        (grvecs d2)
                        (setq t1 d2)
                     )
                  )
               )
            )
         )
      )
      (grvecs t1)
      (setq d1 (list (cadr t1)) i 1)
      (foreach a t1
         (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
         (setq i (1+ i))
      )
      (setq m (getvar "blipmode"))
      (setvar "blipmode" 0)
      (command ".undo" "g")
      (command ".pline" (nth 0 d1) "w" 0 0)
         (foreach i (cdr d1) (command i))
         (command "c")
      (if (= SSP_AUTO_DIMS "1")
         (progn
            (princ "\n[DRAG] Dimension placement:")
            (command ".dim" "hor" (nth 0 d1) (nth 12 d1) pause ""
                            "rot" (setq p (angtos (angle (nth 10 d1) (nth 11 d1)) 0 4)) (nth 3 d1) (nth 11 d1) pause ""
                            "ver" (nth 12 d1) (nth 11 d1) pause "")
                            (setq a (getvar "lastpoint"))
                            (command
                            "ver" (nth 11 d1) (nth 3 d1) a ""
                            "ver" (nth 3 d1) (nth 4 d1) a ""
                            "ver" (nth 1 d1) (nth 8 d1) pause ""
                            "hor" (nth 3 d1) (nth 11 d1) pause "")
                            (setq a (getvar "lastpoint"))
                            (command
                            "hor" (nth 11 d1) (nth 2 d1) a ""
                            "hor" (nth 9 d1) (nth 2 d1) pause ""
                            "rot" p (nth 5 d1) (nth 7 d1) pause ""
                            "hor" (nth 4 d1) (nth 5 d1) pause "" "exit")
            (setq h (distance (nth 10 d1) (nth 2 d1)))
            (setq h (sqrt (- (* h h) (* e e))))
            (setq a (+ (distance (nth 13 d1) (nth 12 d1))
                       (distance (nth 12 d1) (nth 11 d1))
                       (- (distance (nth 2 d1) (nth 3 d1)) h)
                       (distance (nth 3 d1) (nth 4 d1))
                       (distance (nth 4 d1) (nth 5 d1))
                       (distance (nth 5 d1) (nth 6 d1))))
            (initget 1)
            (setq h (strcat "Total Stretch-out = " (rtos a)))
            (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
            (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
         )
      )
      (if (= SSP_DRAW_FILL "1")
         (progn
            (setq p1 (polar (nth 4 d1) (* pi 0.5) (- d e))
                  p9 (nth 4 d1)
                  p8 (nth 5 d1)
                  p7 (nth 6 d1)
                  p6 (nth 7 d1)
                  p2 (polar p1 (angle (nth 0 d1) (nth 1 d1)) (- (+ b (- 1.0 e)) (+ e 0.75)))
                  p3 (polar p2 (* pi 1.5) e)
                  p4 (polar p3 (angle p1 p2) 0.75)
                  p5 (polar p4 (* pi 1.5) 0.75)
            )
            (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 p9 "c")
            (setq a (ssadd (entlast)))
            (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
         )
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)
(defun str_type_b_c (/ a b c d e f g h i l m n ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9)
   (princ "\nDraw Closing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list pi 1.5 0) (list 0 0.5 pi))
   )
   (foreach h g
      (setq p1 (polar a (car h) (+ b e))
            p1 (polar p1 (* pi 1.5) f)
            p2 (polar p1 (* pi 0.5) (- f (- d e)))
            p8 (polar p1 (caddr h) e)
            p7 (polar p8 (* pi 0.5) (- (distance p1 p2) e))
            p6 (polar a (* pi 1.5) d)
            p6 (polar p6 (car h) 1.0)
            p9 (polar a (car h) e)
            p9 (polar p9 (* pi 1.5) (+ e 0.75))
            p3 (polar p6 (+ (angle p9 p6) (* pi (cadr h))) e)
            p4 (polar p3 (angle p6 p9) 1.0)
            p3 (inters p2 (polar p2 (caddr h) 12) p3 p4 nil)
            p4 (polar p3 (angle p6 p9) 0.75)
            p5 (polar p4 (+ (angle p6 p9) (* pi (cadr h))) e)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p1)
            )
         )
      )
      (setq cp (append cp (list p1 p2)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "ver" (nth 0 d1) (nth 6 d1) pause ""
                         "hor" (nth 7 d1) (nth 2 d1) pause ""
                         "rot" (angtos (angle (nth 2 d1) (nth 3 d1)) 0 4) (nth 2 d1) (nth 3 d1) pause "" "exit")
         (setq h (distance (nth 2 d1) (nth 5 d1)))
         (setq h (sqrt (- (* h h) (* e e))))
         (setq i (+ (distance (nth 7 d1) (nth 6 d1))
                    (- (distance (nth 6 d1) (nth 5 d1)) h)
                    (distance (nth 2 d1) (nth 3 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos i)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p9 (nth 1 d1)
               p8 (nth 2 d1)
               p7 (nth 3 d1)
               p6 (nth 4 d1)
               p1 (polar a (angle p8 p9) (+ b e))
               p2 (polar a (angle p8 p9) (+ 0.75 e))
               p3 (polar p2 (angle (nth 1 d1) (nth 0 d1)) e)
               p4 (polar p3 (angle p9 p8) 0.75)
               p5 (polar p4 (angle p2 p3) 0.75)
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 p9 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (princ)
)
(defun str_type_b_d (/ a b c d e f g h i l m n ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14)
   (princ "\nDraw Landing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list 0 0.25 pi 1.5) (list pi 0.75 0 0.5))
   )
   (foreach h g
      (setq p1 (polar a (caddr h) (+ 0.75 e))
            p2 a
            p14 (polar p1 (* pi 1.5) e)
            p13 (polar p14 (car h) 0.75)
            p12 (polar p13 (* pi 1.5) 0.75)
            p11 (polar p2 (* pi 1.5) d)
            p11 (polar p11 (caddr h) 1.0)
            p10 (polar p11 (* pi 1.5) c)
            p9 (polar p10 (car h) (+ b 1.0))
            p5 (polar p10 (* pi (cadr h)) (* e (sqrt 2.0)))
            p6 (polar p9 (* pi (cadr h)) (* e (sqrt 2.0)))
            p8 (polar p9 (* pi 1.5) (- f d))
            p7 (polar p8 (car h) e)
            p3 (polar p12 (+ (angle p11 p12) (* pi (cadddr h))) e)
            p4 (polar p11 (+ (angle p11 p12) (* pi (cadddr h))) e)
            p3 (inters p2 (polar p2 (* pi 1.5) 12) p4 p3 nil)
            p4 (inters p5 (polar p5 (* pi 0.5) 12) p4 p3 nil)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p13 p13 p14 p14 p1)
            )
         )
      )
      (setq cp (append cp (list p6 p7)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 12 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 12 d1) (nth 1 d1) a ""
                         "hor" (nth 1 d1) (nth 8 d1) a ""
                         "hor" (nth 8 d1) (nth 5 d1) a ""
                         "ver" (nth 6 d1) (nth 8 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 8 d1) (nth 5 d1) a ""
                         "ver" (nth 5 d1) (nth 3 d1) a ""
                         "ver" (nth 3 d1) (nth 11 d1) a ""
                         "ver" (nth 11 d1) (nth 12 d1) a ""
                         "ver" (nth 12 d1) (nth 1 d1) a ""
                         "ver" (nth 6 d1) (nth 1 d1) pause ""
                         "rot" (angtos (angle (nth 10 d1) (nth 11 d1)) 0 4) (nth 3 d1) (nth 11 d1) pause ""
                         "hor" (nth 3 d1) (nth 11 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 11 d1) (nth 2 d1) a ""
                         "hor" (nth 10 d1) (nth 2 d1) pause ""
                         "hor" (nth 4 d1) (nth 7 d1) pause "" "exit")
         (setq h (distance (nth 10 d1) (nth 3 d1)))
         (setq h (sqrt (- (* h h) (* e e))))
         (setq a (+ (distance (nth 13 d1) (nth 12 d1))
                    (distance (nth 12 d1) (nth 11 d1))
                    (- (distance (nth 2 d1) (nth 3 d1)) h)
                    (distance (nth 3 d1) (nth 4 d1))
                    (- (distance (nth 4 d1) (nth 5 d1)) e)
                    (distance (nth 8 d1) (nth 7 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos a)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p4 (nth 4 d1)
               p3 (nth 5 d1)
               p1 (polar p4 (* pi 0.5) (- d e))
               p2 (polar p3 (* pi 0.5) (- d e))
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (princ)
)


;;
;; The folowing functions are in support of sloped riser pans
;;
(defun str_type_c_a (/ a b c d e f i l m n ad cp t1 d1 d2 p1 p2 p3 p4 p5 p6 p7 p8)
   (princ "\nDraw Riser Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_RISER_HEIGHT
         c SSP_PAN_FILL
         d SSP_STL_THICKNESS
         e (list (list pi 0 0.5) (list 0 pi 1.5))
   )
   (foreach f e
      (setq p2 a
            p3 (polar p2 (* pi 1.5) b)
            p3 (polar p3 (car f) 1.0)
            p6 (polar p3 (+ (angle p3 p2) (* pi (caddr f))) d)
            p7 (polar p2 (+ (angle p3 p2) (* pi (caddr f))) d)
            p5 (polar p3 (* pi 0.5) d)
            p8 (polar p2 (* pi 1.5) d)
            p7 (inters p7 p6 p8 (polar p8 0 12) nil)
            p6 (inters p7 p6 p5 (polar p5 0 12) nil)
            p8 (polar p7 (car f) 0.75)
            p1 (polar p8 (* pi 0.5) d)
            p5 (polar p6 (car f) 1.0)
            p4 (polar p5 (* pi 1.5) d)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p1)
            )
         )
      )
      (setq cp (append cp (list p4 p5)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".undo" "g")
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 6 d1) pause ""
                         "ali" (nth 6 d1) (nth 5 d1) pause ""
                         "ver" (nth 6 d1) (nth 5 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 6 d1) (nth 1 d1) a ""
                         "ver" (nth 5 d1) (nth 2 d1) a ""
                         "ver" (nth 1 d1) (nth 2 d1) pause ""
                         "hor" (nth 1 d1) (nth 2 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 2 d1) (nth 5 d1) a ""
                         "hor" (nth 5 d1) (nth 3 d1) a "" "exit")
         (setq a (+ (distance (nth 7 d1) (nth 6 d1))
                    (distance (nth 6 d1) (nth 5 d1))
                    (distance (nth 5 d1) (nth 4 d1))))
         (initget 1)
         (setq c (strcat "Total Stretch-out = " (rtos a)))
         (setq b (getpoint (strcat "\n[PICK] Text left justification point: <" c "> ")))
         (command ".text" b (* (getvar "dimscale") (getvar "dimtxt")) 0 c)
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)
(defun str_type_c_b (/ a b c d e f g h i l m n p ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14)
   (setq b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
   )
   (while (progn
             (princ "\nDraw Stair Pan Section.")
             (setq a (getpoint "\n[PICK] nosing point: "))
          )
      (setq ad nil cp nil)
      (setq f (list (list 0 0.5 pi 1.25) (list pi 1.5 0 1.75)))
      (foreach g f
         (setq p2 a
               p3 (polar p2 (* pi 1.5) c)
               p3 (polar p3 (caddr g) 1.0)
               p4 (polar p3 (* pi 1.5) (- d e))
               p9 (polar p4 (* pi (cadddr g)) (* e (sqrt 2.0)))
               p11 (polar p2 (+ (angle p3 p2) (* pi (cadr g))) e)
               p10 (polar p3 (+ (angle p3 p2) (* pi (cadr g))) e)
               p12 (polar p2 (* pi 1.5) e)
               p11 (inters p10 p11 p12 (polar p12 (caddr g) 12) nil)
               p12 (polar p11 (caddr g) 0.75)
               p1 (polar p12 (* pi 0.5) e)
               p10 (inters p10 p11 p9 (polar p9 (* pi (cadr g)) 12) nil)
               p13 (polar p2 (* pi 1.5) d)
               p14 (polar p13 (caddr g) 3.0)
               p13 (inters p10 p11 p13 p14 nil)
               p14 (inters p3 p4 p13 p14 nil)
               p13 (distance p13 p14)
               p8 (polar p2 (* pi 1.5) (+ c d))
               p8 (polar p8 (car g) (+ p13 (- b 1.0)))
               p5 (polar p8 (+ (angle p3 p2) (* pi (cadr g))) e)
               p6 (polar p5 (angle p3 p2) 1.0)
               p5 (inters p5 p6 p4 (polar p4 (caddr g) 12.0) nil)
               p6 (polar p5 (angle p3 p2) 0.75)
               p7 (polar p6 (+ (angle p2 p3) (* pi (cadr g))) e)
         )
         (setq ad
            (append ad
               (list
                  (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p1)
               )
            )
         )
         (setq cp (append cp (list p7 p8)))
      )
      (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
      (setq d1 (car ad) d2 (cadr ad) t1 d1)
      (grvecs d1)
      (princ "\n[DRAG] Pan direction and [PICK]: ")
      (grread 5)
      (while (/= 3 (car (setq l (grread 5))))
         (if (= 5 (car l))
            (progn
               (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
               (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
               (if (< n m)
                  (if (not (equal t1 d1))
                     (progn
                        (grvecs t1)
                        (grvecs d1)
                        (setq t1 d1)
                     )
                  )
                  (if (not (equal t1 d2))
                     (progn
                        (grvecs t1)
                        (grvecs d2)
                        (setq t1 d2)
                     )
                  )
               )
            )
         )
      )
      (grvecs t1)
      (setq d1 (list (cadr t1)) i 1)
      (foreach a t1
         (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
         (setq i (1+ i))
      )
      (setq m (getvar "blipmode"))
      (setvar "blipmode" 0)
      (command ".undo" "g")
      (command ".pline" (nth 0 d1) "w" 0 0)
         (foreach i (cdr d1) (command i))
         (command "c")
      (if (= SSP_AUTO_DIMS "1")
         (progn
            (princ "\n[DRAG] Dimension placement:")
            (command ".dim" "hor" (nth 0 d1) (nth 10 d1) pause ""
                            "rot" (setq p (angtos (angle (nth 2 d1) (nth 1 d1)) 0 4)) (nth 10 d1) (nth 2 d1) pause ""
                            "ver" (nth 10 d1) (nth 2 d1) pause "")
                            (setq a (getvar "lastpoint"))
                            (command
                            "ver" (nth 10 d1) (nth 1 d1) a ""
                            "ver" (nth 2 d1) (nth 4 d1) a ""
                            "ver" (nth 4 d1) (nth 7 d1) a ""
                            "ver" (nth 1 d1) (nth 7 d1) pause ""
                            "rot" p (nth 4 d1) (nth 6 d1) pause ""
                            "hor" (nth 1 d1) (nth 3 d1) pause ""
                            "hor" (nth 3 d1) (nth 4 d1) pause "" "exit")
            (setq h (distance (nth 9 d1) (nth 2 d1)))
            (setq h (sqrt (- (* h h) (* e e))))
            (setq a (+ (distance (nth 11 d1) (nth 10 d1))
                       (- (distance (nth 10 d1) (nth 9 d1)) h)
                       (distance (nth 2 d1) (nth 3 d1))
                       (distance (nth 3 d1) (nth 4 d1))
                       (distance (nth 4 d1) (nth 5 d1))))
            (initget 1)
            (setq h (strcat "Total Stretch-out = " (rtos a)))
            (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
            (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
         )
      )
      (if (= SSP_DRAW_FILL "1")
         (progn
            (setq p1 (nth 2 d1)
                  p8 (nth 3 d1)
                  p7 (nth 4 d1)
                  p6 (nth 5 d1)
                  p5 (nth 6 d1)
                  p4 (polar (nth 1 d1) (angle (nth 0 d1) (nth 1 d1)) b)
                  p4 (polar p4 (* pi 1.5) c)
                  p4 (polar p4 (angle (nth 1 d1) (nth 10 d1)) (distance (nth 1 d1) (nth 10 d1)))
                  p3 (polar p4 (angle (nth 10 d1) (nth 11 d1)) (distance (nth 10 d1) (nth 11 d1)))
                  p2 (polar p3 (angle (nth 11 d1) (nth 0 d1)) (distance (nth 11 d1) (nth 0 d1)))
            )
            (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 "c")
            (setq a (ssadd (entlast)))
            (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
         )
      )
   )
   (setvar "blipmode" m)
   (command ".undo" "e")
   (princ)
)
(defun str_type_c_c (/ a b c d e f g h i l m n ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9)
   (princ "\nDraw Closing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list pi 1.5 0) (list 0 0.5 pi))
   )
   (foreach h g
      (setq p1 (polar a (car h) (+ b e))
            p1 (polar p1 (* pi 1.5) f)
            p2 (polar p1 (* pi 0.5) (- f (- d e)))
            p8 (polar p1 (caddr h) e)
            p7 (polar p8 (* pi 0.5) (- (distance p1 p2) e))
            p3 (polar a (* pi 1.5) c)
            p3 (polar p3 (car h) 1.0)
            p4 (polar a (* pi 1.5) d)
            p3 (inters a p3 p4 (polar p4 0 12) nil)
            p5 (polar a (+ (angle a p3) (* pi (cadr h))) e)
            p6 (polar p3 (+ (angle a p3) (* pi (cadr h))) e)
            p6 (inters p5 p6 p3 p4 nil)
            p4 p3
            p3 (polar p6 (+ (angle a p4) (* pi (cadr h))) e)
            p4 (polar p3 (angle p4 a) 3.0)
            p3 (inters p2 (polar p2 (caddr h) 12.0) p3 p4 nil)
            p4 (polar p3 (angle p3 p4) 0.75)
            p5 (polar p4 (+ (angle p3 p4) (* pi (cadr h))) e)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p1)
            )
         )
      )
      (setq cp (append cp (list p1 p2)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "ver" (nth 0 d1) (nth 6 d1) pause ""
                         "hor" (nth 7 d1) (nth 2 d1) pause ""
                         "rot" (angtos (angle (nth 2 d1) (nth 3 d1)) 0 4) (nth 2 d1) (nth 3 d1) pause "" "exit")
         (setq i (+ (distance (nth 7 d1) (nth 6 d1))
                    (- (distance (nth 1 d1) (nth 2 d1)) e)
                    (distance (nth 2 d1) (nth 3 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos i)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p8 (nth 1 d1)
               p7 (nth 2 d1)
               p6 (nth 3 d1)
               p5 (nth 4 d1)
               p1 (polar a (angle p7 p8) (+ b e))
               p3 (polar (nth 5 d1) (* pi 0.5) (- d e))
               p4 (inters (nth 4 d1) (nth 5 d1) p3 (polar p3 0 12) nil)
               p3 (polar p4 (angle p7 p8) 0.75)
               p2 (polar p3 (* pi 0.5) e)
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 p5 p6 p7 p8 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (princ)
)
(defun str_type_c_d (/ a b c d e f g h i l m n ad cp t1 d1 d2
                       p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 p13 p14)
   (princ "\nDraw Landing Pan Section.")
   (setq a (getpoint "\n[PICK] Nosing point: ")
         b SSP_PAN_WIDTH
         c SSP_RISER_HEIGHT
         d SSP_PAN_FILL
         e SSP_STL_THICKNESS
         f SSP_LANDING_FILL
         g (list (list 0 0.5 pi 1.25) (list pi 1.5 0 1.75))
   )
   (foreach h g
      (setq p2 a
            p3 (polar p2 (* pi 1.5) c)
            p3 (polar p3 (caddr h) 1.0)
            p4 (polar p3 (* pi 1.5) (- d e))
            p9 (polar p4 (* pi (cadddr h)) (* e (sqrt 2.0)))
            p11 (polar p2 (+ (angle p3 p2) (* pi (cadr h))) e)
            p10 (polar p3 (+ (angle p3 p2) (* pi (cadr h))) e)
            p12 (polar p2 (* pi 1.5) e)
            p11 (inters p10 p11 p12 (polar p12 (caddr h) 12) nil)
            p12 (polar p11 (caddr h) 0.75)
            p1 (polar p12 (* pi 0.5) e)
            p10 (inters p10 p11 p9 (polar p9 (* pi (cadr h)) 12) nil)
            p5 (polar p4 (car h) (+ 1.0 b e))
            p8 (polar p9 (car h) (+ 1.0 b e))
            p7 (polar p8 (* pi 1.5) (- f d))
            p6 (polar p7 (car h) e)
      )
      (setq ad
         (append ad
            (list
               (list 256 p1 p2 p2 p3 p3 p4 p4 p5 p5 p6 p6 p7 p7 p8 p8 p9 p9 p10 p10 p11 p11 p12 p12 p1)
            )
         )
      )
      (setq cp (append cp (list p5 p6)))
   )
   (setq p1 (car cp) p2 (cadr cp) p3 (caddr cp) p4 (cadddr cp))
   (setq d1 (car ad) d2 (cadr ad) t1 d1)
   (grvecs d1)
   (princ "\n[DRAG] Pan direction and [PICK]: ")
   (grread 5)
   (while (/= 3 (car (setq l (grread 5))))
      (if (= 5 (car l))
         (progn
            (setq n (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p1 p2 nil)))
            (setq m (distance (cadr l) (inters (cadr l) (polar (cadr l) 0 12.0) p3 p4 nil)))
            (if (< n m)
               (if (not (equal t1 d1))
                  (progn
                     (grvecs t1)
                     (grvecs d1)
                     (setq t1 d1)
                  )
               )
               (if (not (equal t1 d2))
                  (progn
                     (grvecs t1)
                     (grvecs d2)
                     (setq t1 d2)
                  )
               )
            )
         )
      )
   )
   (grvecs t1)
   (setq d1 (list (cadr t1)) i 1)
   (foreach a t1
      (if (zerop (rem i 2)) (setq d1 (append d1 (list (nth i t1)))))
      (setq i (1+ i))
   )
   (setq m (getvar "blipmode"))
   (setvar "blipmode" 0)
   (command ".pline" (nth 0 d1) "w" 0 0)
      (foreach i (cdr d1) (command i))
      (command "c")
   (if (= SSP_AUTO_DIMS "1")
      (progn
         (princ "\n[DRAG] Dimension placement:")
         (command ".dim" "hor" (nth 0 d1) (nth 10 d1) pause ""
                         "ver" (nth 5 d1) (nth 7 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "ver" (nth 7 d1) (nth 4 d1) a ""
                         "ver" (nth 4 d1) (nth 2 d1) a ""
                         "ver" (nth 2 d1) (nth 10 d1) a ""
                         "ver" (nth 10 d1) (nth 1 d1) a ""
                         "ver" (nth 5 d1) (nth 1 d1) pause ""
                         "rot" (angtos (angle (nth 9 d1) (nth 10 d1)) 0 4) (nth 2 d1) (nth 10 d1) pause ""
                         "hor" (nth 2 d1) (nth 10 d1) pause ""
                         "hor" (nth 2 d1) (nth 1 d1) pause "")
                         (setq a (getvar "lastpoint"))
                         (command
                         "hor" (nth 1 d1) (nth 6 d1) a ""
                         "hor" (nth 3 d1) (nth 6 d1) pause "" "exit")
         (setq h (distance (nth 9 d1) (nth 2 d1)))
         (setq h (sqrt (- (* h h) (* e e))))
         (setq a (+ (distance (nth 11 d1) (nth 10 d1))
                    (- (distance (nth 10 d1) (nth 9 d1)) h)
                    (distance (nth 2 d1) (nth 3 d1))
                    (- (distance (nth 3 d1) (nth 4 d1)) e)
                    (distance (nth 7 d1) (nth 6 d1))))
         (initget 1)
         (setq h (strcat "Total Stretch-out = " (rtos a)))
         (setq g (getpoint (strcat "\n[PICK] Text left justification point: <" h "> ")))
         (command ".text" g (* (getvar "dimscale") (getvar "dimtxt")) 0 h)
      )
   )
   (if (= SSP_DRAW_FILL "1")
      (progn
         (setq p1 (nth 2 d1)
               p4 (nth 3 d1)
               p3 (nth 4 d1)
               p2 (polar p3 (* pi 0.5) (- d e))
         )
         (command ".pline" p1 "w" 0 0 p2 p3 p4 "c")
         (setq a (ssadd (entlast)))
         (command ".hatch" "sacncr" (getvar "dimscale") "" a "")
      )
   )
   (setvar "blipmode" m)
   (princ)
)


;;
;; The following functions are in support of C:SSP
;;
(defun ssp_b (x / a b c)
   (setq SSP_DEFAULTS
      (list
         x
         (cadr SSP_DEFAULTS)
         (caddr SSP_DEFAULTS)
         (cadddr SSP_DEFAULTS)
         (last SSP_DEFAULTS)
      )
   )
)
(defun ssp_c (x y / a b)
   (if (and y) (setq SSP_NOSE_NOSE nil))
   (if (= x "NOSE to NOSE DISTANCE")
      (progn
         (initget 1)
         (setq a (getpoint "\n[PICK] First nosing point: "))
         (initget 1)
         (setq b (getpoint a "\n[PICK] Second nosing point: ")
               SSP_NOSE_NOSE (distance a b)
               SSP_PAN_WIDTH (- (max (car a) (car b)) (min (car a) (car b)))
               SSP_RISER_HEIGHT (- (max (cadr a) (cadr b)) (min (cadr a) (cadr b)))
         )
      )
      (progn
         (princ "\nEnter value or select two points.")
         (setq a (getdist (strcat "\n>>Enter " x " value: ")))
      )
   )
   (cond
      ((not SSP_PAN_WIDTH))
      ((not SSP_RISER_HEIGHT))
      (t (setq SSP_NOSE_NOSE
            (sqrt
               (+ (* SSP_PAN_WIDTH SSP_PAN_WIDTH) (* SSP_RISER_HEIGHT SSP_RISER_HEIGHT))
            )
         )
      )
   )
   a
)
(defun ssp_d (x)
   (cond
      ((= x "pan_width")    (setq SSP_PAN_WIDTH    (distof (get_tile x))))
      ((= x "riser_hgt")    (setq SSP_RISER_HEIGHT (distof (get_tile x))))
      ((= x "pan_fill" )    (setq SSP_PAN_FILL     (distof (get_tile x))))
      ((= x "landing_fill") (setq SSP_LANDING_FILL (distof (get_tile x))))
   )
   (if (/= x "") (set_tile "err_msg" ""))
)
(defun ssp_e ()
   (setq SSP_STL_THICKNESS (ssp_get_thickness))
   (setq SSP_DEFAULTS
      (list
         (car SSP_DEFAULTS)
         (cadr SSP_DEFAULTS)
         (caddr SSP_DEFAULTS)
         (get_tile "ssp_gage")
         SSP_STL_THICKNESS
      )
   )
)
(defun ssp_get_thickness (/ a)
   (setq a (nth (atoi (cadddr SSP_DEFAULTS)) (cdr (caddr SSP_DEFAULTS))))
   (setq SSP_STL_THICKNESS
      (cond
         ((= a "16 gage") 0.0598)
         ((= a "15 gage") 0.0673)
         ((= a "14 gage") 0.0747)
         ((= a "13 gage") 0.0897)
         ((= a "12 gage") 0.1046)
         ((= a "11 gage") 0.1233)
         ((= a "10 gage") 0.1345)
         ((= a "9 gage" ) 0.1495)
         ((= a "8 gage" ) 0.1644)
      )
   )
)
(defun ssp_f ()
   (eval (list (read (strcat (car SSP_DEFAULTS) (substr (cadr SSP_DEFAULTS) 9)))))
)
(defun ssp_g ()
   (setq SSP_DEFAULTS
      (list
         (car SSP_DEFAULTS)
         (get_tile "pan_type")
         (caddr SSP_DEFAULTS)
         (cadddr SSP_DEFAULTS)
         (last SSP_DEFAULTS)
      )
   )
)
(defun ssp_h ()
   (setq a
      (cond
         ((= "" (get_tile "pan_width")) "Tread Width")
         ((= "" (get_tile "riser_hgt")) "Riser Height")
         ((= "" (get_tile "pan_fill")) "Pan Fill Depth")
         ((= (get_tile "pan_type") "pan_type_a") nil)
         ((= (get_tile "pan_type") "pan_type_b") nil)
         ((= "" (get_tile "landing_fill")) "Landing Fill Depth")
         (t nil)
      )
   )
   (if (and a)
      (progn
         (set_tile "err_msg" (strcat "You must provide a " a))
         nil
      )
      (progn
         (done_dialog)
         (setq b 0)
      )
   )
)
(defun c:steel_stair_pans (/ a b c ssp_a)
   (setq ssp_a *error*
         *error* '((a)
            (cond
               ((= (setq a (strcase a)) "FUNCTION CANCELLED") (princ "\n*Function Cancelled by User*"))
               (t (princ (strcat "\n*AutoLisp Error* [" a "]")))
            )
            (setq *error* ssp_a)
            (princ)
         )
   )
   (cond
      (SSP_DCL_FILE)
      ((setq a (findfile "str_pans.dcl")) (ssp_init a)); Assumed Startup -- Initialize globals
      ((setq a (findfile "str_pans.dcl")))
      (t (alert "Can not find file STR_PANS.DCL\n\nMake sure this file is in your ACAD search path."))
   )
   (cond
      (SSP_DCL_FILE
         (if (not SSP_DEFAULTS)
            (setq SSP_DEFAULTS
              '("str_type_a"
                "pan_type_a"
                ("16 gage" "15 gage" "14 gage" "13 gage" "12 gage" "11 gage" "10 gage" "9 gage" "8 gage")
                "4"
                0.1046)
            )
         )
         (while (not c)
            (new_dialog "steel_stair_pans" SSP_DCL_FILE)
            (set_tile (car SSP_DEFAULTS) "1")
            (set_tile (cadr SSP_DEFAULTS) "1")
            (start_list "ssp_gage")
            (mapcar 'add_list (caddr SSP_DEFAULTS))
            (end_list)
            (set_tile "ssp_gage" (cadddr SSP_DEFAULTS))
            (action_tile "stair_type" "(ssp_b (get_tile \"stair_type\"))")
            (if (and SSP_PAN_WIDTH)    (set_tile "pan_width"    (rtos SSP_PAN_WIDTH)))
            (if (and SSP_RISER_HEIGHT) (set_tile "riser_hgt"    (rtos SSP_RISER_HEIGHT)))
            (if (and SSP_PAN_FILL)     (set_tile "pan_fill"     (rtos SSP_PAN_FILL)))
            (if (and SSP_LANDING_FILL) (set_tile "landing_fill" (rtos SSP_LANDING_FILL)))
            (if (not SSP_STL_THICKNESS) (setq SSP_STL_THICKNESS (last SSP_DEFAULTS)))
            (if (and SSP_DRAW_FILL) (set_tile "draw_pan_fill" SSP_DRAW_FILL))
            (if (and SSP_AUTO_DIMS) (set_tile "pan_dims" SSP_AUTO_DIMS))
            (cond
               ((not SSP_PAN_WIDTH))
               ((not SSP_RISER_HEIGHT))
               (t (setq SSP_NOSE_NOSE
                     (sqrt
                        (+ (* SSP_PAN_WIDTH SSP_PAN_WIDTH) (* SSP_RISER_HEIGHT SSP_RISER_HEIGHT))
                     )
                  )
               )
            )
            (if (and SSP_NOSE_NOSE) (set_tile "nose_nose" (rtos SSP_NOSE_NOSE)))
            (if (= (car SSP_DEFAULTS) "str_type_d")
               (progn
                  (mapcar 'set_tile '("pan_fill" "landing_fill") '("" ""))
                  (mapcar 'mode_tile '("pan_fill" "pan_button" "landing_fill" "landing_button") '(1 1 1 1))
               )
            )
            (action_tile "pan_width"    "(ssp_d \"pan_width\")")
            (action_tile "riser_hgt"    "(ssp_d \"riser_hgt\")")
            (action_tile "pan_fill"     "(ssp_d \"pan_fill\")")
            (action_tile "landing_fill" "(ssp_d \"landing_fill\")")
            (action_tile "width_button"   "(progn (done_dialog) (setq b 1))")
            (action_tile "riser_button"   "(progn (done_dialog) (setq b 2))")
            (action_tile "pan_button"     "(progn (done_dialog) (setq b 3))")
            (action_tile "landing_button" "(progn (done_dialog) (setq b 4))")
            (action_tile "nose_button"    "(progn (done_dialog) (setq b 5))")
            (action_tile "draw_pan_fill" "(setq SSP_DRAW_FILL (get_tile \"draw_pan_fill\"))")
            (action_tile "pan_dims" "(setq SSP_AUTO_DIMS (get_tile \"pan_dims\"))")
            (action_tile "pan_type" "(ssp_g)")
            (action_tile "ssp_gage" "(ssp_e)")
            (action_tile "about_button" "(ssp_about)")
            (action_tile "ssp_a" "(setq c (ssp_h))")
            (action_tile "ssp_b" "(progn (done_dialog) (setq b nil c t))")
            (start_dialog)
            (initget 1)
            (cond
               ((= b 0) (ssp_f))
               ((= b 1) (setq SSP_PAN_WIDTH    (ssp_c "TREAD WIDTH" t)))
               ((= b 2) (setq SSP_RISER_HEIGHT (ssp_c "RISER HEIGHT" t)))
               ((= b 3) (setq SSP_PAN_FILL     (ssp_c "PAN FILL DEPTH" nil)))
               ((= b 4) (setq SSP_LANDING_FILL (ssp_c "LANDING FILL DEPTH" nil)))
               ((= b 5) (ssp_c "NOSE to NOSE DISTANCE" nil))
            )
         )
      )
   )
   (setq *error* ssp_a)
   (princ)
)
(defun c:ssp () (c:steel_stair_pans))
(princ "\nSteel Stair Pans by Design Point is now loaded.")
(princ "\nType SSP to start command.")
(princ)
