//   Steel Shapes Dialog Box  Version 2.5
//
//   (C) Copyright 1999 by Design Point
//   All rights reserved
//
//   This program is copyrighted by Design Point and is licensed
//   to you under the following conditions.  You may not distribute
//   or publish the source code of this program in any form.
//
//   DESIGN POINT PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.
//   DESIGN POINT SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MER-
//   CHANTABILITY OR FITNESS FOR A PARTICULAR USE.  DESIGN POINT
//   DOES NOT WARRANT THAT THE OPERATION OF THIS OR PARTS OF THIS
//   PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
//

// This file to be used in conjuction with STEEL.LSP

steel_stair_pans : dialog {
   label = "Steel Stair Pans";
   : boxed_radio_row {
      label = "Select stair type";
      key = stair_type;
      fixed_width = true;
      alignment = centered;
      : radio_button {
         label = "Square nosing";
         key   = str_type_a;
         is_tab_stop = false;
      }
      : radio_button {
         label = "Sloped nosing";
         key   = str_type_b;
         is_tab_stop = false;
      }
      : radio_button {
         label = "Sloped riser";
         key   = str_type_c;
         is_tab_stop = false;
      }
   }
   : row {
      : boxed_radio_row {
         label = "Select pan type";
         key   = pan_type;
         : radio_button {
            label = "Riser pan";
            key   = pan_type_a;
            is_tab_stop = false;
         }
         : radio_button {
            label = "Stair pan";
            key   = pan_type_b;
            is_tab_stop = false;
         }
         : radio_button {
            label = "Closing pan";
            key   = pan_type_c;
            is_tab_stop = false;
         }
         : radio_button {
            label = "Landing pan";
            key   = pan_type_d;
            is_tab_stop = false;
         }
      }
   }
   : row {
      : boxed_row {
         label = "Tread Dimensions";
         fixed_width = true;
         fixed_height = true;
         alignment   = centered;
         : column {
            : text { label = "Nose to Nose distance"; height = 1.25; alignment = right;}
            : text { label = "Tread width"; height = 1.25; alignment = right;}
            : text { label = "Riser height"; height = 1.25; alignment = right;}
            : text { label = "Pan fill depth"; height = 1.25; alignment = right;}
            : text { label = "Landing fill depth"; height = 1.25; alignment = right;}
         }
         : column {
            : edit_box {
               key   = nose_nose;
               width = 15;
            }
            : edit_box {
               key   = pan_width;
               width = 15;
            }
            : edit_box {
               key   = riser_hgt;
               width = 15;
            }
            : edit_box {
               key   = pan_fill;
               width = 15;
            }
            : edit_box {
               key   = landing_fill;
               width = 15;
            }
         }
         : column {
            fixed_width  = true;
            : button {
               label = "Pick >";
               key   = nose_button;
               width = 10;
               is_tab_stop = false;
            }
            fixed_width  = true;
            : button {
               label = "Pick >";
               key   = width_button;
               width = 10;
               is_tab_stop = false;
            }
            : button {
               label = "Pick >";
               key   = riser_button;
               width = 10;
               is_tab_stop = false;
            }
            : button {
               label = "Pick >";
               key   = pan_button;
               width = 10;
               is_tab_stop = false;
            }
            : button {
               label = "Pick >";
               key   = landing_button;
               width = 10;
               is_tab_stop = false;
            }
         }
      }
      : column {
         : text { label = "Select Sheet Metal Gage";}
         : popup_list {
            width = 20;
            key   = ssp_gage;
            height = 9;
            is_tab_stop = false;
         }
         spacer_1;
         : boxed_column {
            label = "Extras";
            : toggle {
               label = "Draw concrete fill";
               key   = draw_pan_fill;
               is_tab_stop = false;
            }
            : toggle {
               label = "Auto-Dimension";
               key   = pan_dims;
               is_tab_stop = false;
            }
         }
      }
   }
   : text { label = ""; key = err_msg;}
   : row {
      alignment   = centered;
      fixed_width = true;
      : button {
         label       = "OK";
         key         = "ssp_a";
         width       = 10;
         is_default  = true;
      }
      : button {
         label       = "Cancel";
         key         = "ssp_b";
         width       = 10;
         is_default  = true;
      }
      : button {
         label       = "About";
         key         = "about_button";
         width       = 10;
      }
   }
}
ssp_about : dialog {
   label = "About Steel Stair Pan";
   : boxed_row {
      : paragraph {
         : text_part {
            alignment   = centered;
            label       = "Steel Stair Pan (tm)";
         }
         : text_part {
            alignment   = centered;
            label       = "Version 2.5";
         }
         : text_part {
            alignment   = centered;
            label       = "(c) Copyright Design Point 1999";
         }
         : text_part {
            alignment   = centered;
            label       = "All Rights Reserved";
            is_cancel = true;
         }
         spacer_1;
         : text_part {
            alignment   = centered;
            label       = "Visit our web site at";
            is_cancel = true;
         }
         : text_part {
            alignment   = centered;
            label       = "http://www.designpt.com";
            is_cancel = true;
         }
         spacer_1;
         : text_part {
            alignment   = centered;
            label       = "Address comments to luke@designpt.com";
            is_cancel = true;
         }
      }
   }
   ok_only;
}
