;TEXTSIZE.lsp 05/02/97 Jeff Foster
;
;OBJECTIVE***
;The purpose of this routine is to allow the user to easily
;calculate text heights based upon a given scale.
;
;TO RUN***
;At the command line, type (load "c:/lispdir/textsize")
;where c:/ is the drive where TEXTSIZE.lsp is contained
;where lispdir/ is the directory where TEXTSIZE.lsp is contained
;
;
;If you find this routine to be helpful, please give consideration
;to making a cash contribution of $10.00 to:
;         Jeff Foster
;         590 Penny Rd.
;         Angier, NC 27501
;
(Defun c:textsize ()
  (setq c_scl (getvar "dimscale"))
  (setq c_styl (getvar "textstyle"))
  (setq c_unit (getvar "lunits"))
  (cond
    ((= c_unit 1) (setq u1 "Scientific units"))
    ((= c_unit 2) (setq u1 "Decimal units"))
    ((= c_unit 3) (setq u1 "Engineering units"))
    ((= c_unit 4) (setq u1 "Architectural units"))
    ((= c_unit 5) (setq u1 "Fractional units"))
  )
  (prompt (strcat "\nCurrent unit style is " u1))
  (initget 1 "Y y N n")
  (setq prmpt (getkword "\nDo you wish to change it? <Y or N>: "))
  (cond
    ((or (= prmpt "Y") (= prmpt "y"))
      (command "units" pause pause "" "" "" "")
    )
  )
  (prompt (strcat "\nCurrent scale is 1=" (itoa (fix c_scl))))
  (initget 1 "Y y N n")
  (setq prmpt (getkword "\nDo you wish to change it? <Y or N>: "))
  (setq n_scl c_scl)
  (setq n_unit (getvar "lunits"))
  (cond
    ((or (= prmpt "Y") (= prmpt "y"))
      (setq n_scl (getreal "\nEnter new scale <i.e. 50 for 1=50>: "))
      (setvar "dimscale" (fix n_scl))
    )
  )
  (cond
    ((= n_unit 1) (TypeOne))
    ((= n_unit 2) (TypeTwo))
    ((= n_unit 3) (TypeThree))
    ((= n_unit 4) (TypeFour))
    ((= n_unit 5) (TypeFive))
  )
)

(defun TypeOne ()
  (textscr)
  (prompt (strcat "\nFor 0\.08  text, enter " (rtos (* 0.08 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.10  text, enter " (rtos (* 0.10 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.125 text, enter " (rtos (* 0.125 n_scl) 2 2)))
  (prompt "\n")
)
(defun TypeTwo ()
  (textscr)
  (prompt (strcat "\nFor 0\.08\"  text, enter " (rtos (* 0.08 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.10\"  text, enter " (rtos (* 0.10 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.125\" text, enter " (rtos (* 0.125 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.175\" text, enter " (rtos (* 0.175 n_scl) 2 2)))
  (prompt (strcat "\nFor 0\.20\"  text, enter " (rtos (* 0.20 n_scl) 2 2)))
  (prompt "\n")
)
(defun TypeThree ()
  (textscr)
  (prompt (strcat "\nFor 1\/16\" text, enter " (rtos (* 0.0625 n_scl) 3 3)))
  (prompt (strcat "\nFor 0\.10\" text, enter " (rtos (* 0.10 n_scl) 3 3)))
  (prompt (strcat "\nFor 3\/32\" text, enter " (rtos (* (/ 3.0 32.0) n_scl) 3 3)))
  (prompt (strcat "\nFor 1\/8\"  text, enter " (rtos (* 0.125 n_scl) 3 3)))
  (prompt (strcat "\nFor 5\/32\" text, enter " (rtos (* (/ 5.0 32.0) n_scl) 3 3)))
  (prompt (strcat "\nFor 3\/16\" text, enter " (rtos (* (/ 3.0 16.0) n_scl) 3 3)))
  (prompt (strcat "\nFor 1\/4\"  text, enter " (rtos (* 0.25 n_scl) 3 3)))
  (prompt (strcat "\nFor 5\/16\" text, enter " (rtos (* (/ 5.0 16.0) n_scl) 3 3)))
  (prompt (strcat "\nFor 3\/8\"  text, enter " (rtos (* 0.375 n_scl) 3 3)))
  (prompt (strcat "\nFor 1\/2\"  text, enter " (rtos (* 0.50 n_scl) 3 3)))
  (prompt "\n")
)
(defun TypeFour ()
  (textscr)
  (prompt (strcat "\nFor 1\/16\" text, enter " (rtos (* 0.0625 n_scl) 2 3)))
  (prompt (strcat "\nFor 0\.10\" text, enter " (rtos (* 0.10 n_scl) 2 3)))
  (prompt (strcat "\nFor 3\/32\" text, enter " (rtos (* (/ 3.0 32.0) n_scl) 2 3)))
  (prompt (strcat "\nFor 1\/8\"  text, enter " (rtos (* 0.125 n_scl) 2 3)))
  (prompt (strcat "\nFor 5\/32\" text, enter " (rtos (* (/ 5.0 32.0) n_scl) 2 3)))
  (prompt (strcat "\nFor 3\/16\" text, enter " (rtos (* (/ 3.0 16.0) n_scl) 2 3)))
  (prompt (strcat "\nFor 1\/4\"  text, enter " (rtos (* 0.25 n_scl) 2 3)))
  (prompt (strcat "\nFor 5\/16\" text, enter " (rtos (* (/ 5.0 16.0) n_scl) 2 3)))
  (prompt (strcat "\nFor 3\/8\"  text, enter " (rtos (* 0.375 n_scl) 2 3)))
  (prompt (strcat "\nFor 1\/2\"  text, enter " (rtos (* 0.50 n_scl) 2 3)))
  (prompt "\n")
)
(defun TypeFive ()
  (textscr)
  (prompt "\nNo information available")
  (prompt "\n")
)
