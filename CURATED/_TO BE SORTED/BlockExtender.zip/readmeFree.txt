BlockExtender Beta 1.0
Shareware
Copyright, Vista, 2000 - 2003

First release of BlockExtender
http:/www.objectdcl.com/BlockExtender.html

BlockExtender is a brand new technology that allows you to turn almost any block into a custom entity on the fly.



AutoCAD 2004 installation:

Once the software is installed you must setup AutoCAD 2004 to load the BlockExtDbx4.dbx and BlockExtenderFree4.arx.

To do this, type in APPLOAD at the command line. Next in the lower right corner of the dialog box, 

click on the "Contents" button. A new dialog will appear, click on the "Add" button. Then go to the

installation directory and select the BlockExtDbx4.dbx file. This file contains the intelligent 

block tool. Then click the "Add" button again then select the  BlockExtenderFree4.arx file. This file displays 

the dialog boxes. 



AutoCAD 2000 - 2002 installation:

Once the software is installed you must setup AutoCAD to load the BlkeBlockExtDbx.dbx and BlockExtenderFree.arx.

To do this, type in APPLOAD at the command line. Next in the lower right corner of the dialog box, 

click on the "Contents" button. A new dialog will appear, click on the "Add" button. Then go to the

installation directory and select the BlkeBlockExtDbx.dbx file. This file contains the intelligent 

block tool. Then click the "Add" button again then select the  BlockExtenderFree.arx file. This file displays 

the dialog boxes. Then click the "Add" button again then select the  BlockExtVba.arx file. This file

manages the OPM (Object Properties Manager property list box and exported VBA API functionality All

three files are required.  



Block Extender is now ready.
