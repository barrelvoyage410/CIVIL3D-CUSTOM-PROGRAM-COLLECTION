BlockExtender Beta 1.0
Shareware
Copyright, Vista, 2000 - 2003

First release of BlockExtender
http:/www.objectdcl.com/BlockExtender.html

BlockExtender is a brand new technology that allows you to turn almost any block into a custom entity on the fly.



AutoCAD installation:

Once the software is installed you must setup AutoCAD to load the BlockExtender.dbx and BLockUI.arx.

To do this, type in APPLOAD at the command line. Next in the lower right corner of the dialog box, 

click on the "Contents" button. A new dialog will appear, click on the "Add" button. Then go to 

the installation directory and select the BlockExtender.dbx file. Then click the "Add" button again then select

the  BLockUI.arx file. Block Extender is now ready.
