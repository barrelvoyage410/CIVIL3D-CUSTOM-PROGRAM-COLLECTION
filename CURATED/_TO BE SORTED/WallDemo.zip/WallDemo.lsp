
;Developped by Michel Tint, 2002. misha_t@zahav.net.il
;---------------------------------------------------------
;---------------------------------------------------------
;---------------------------------------------------------
;---------------------------------------------------------
 (defun c:unloadwalldemo ( / )
  (setvar "cmdecho" 0) 
  (setvar "filedia" 0)
    (command "menuunload" "WallDemo")
 (setvar "filedia" 1)
(princ)
    )

(defun PlaceMichaelMenu (/ CNT)
  (setq CNT 1)
  (while (< CNT 24)
    (if (menucmd (strcat "P" (itoa CNT) ".1=?"))
      (setq CNT (1+ CNT))
      (progn
        (if (> CNT 2)
          (setq CNT (1- CNT))
          (setq CNT 2)
        )
        (menucmd (strcat "p" (itoa CNT) "=+WallDemo.pop1"))
        (setq CNT 25)
      )
    )
  )
)
(defun c:loadwalldemo ( / )
  (setvar "cmdecho" 0)
  (if (findfile "WallDemo.dvb")
    (progn
      (setvar "filedia" 0)
    (command "menuunload" "WallDemo")
  (command "menuload" "WallDemo")
     (placemichaelmenu)
      (command "_vbaload" (findfile "Walldemo.dvb"))
    
      (setvar "filedia" 1)
    )
    (princ
      "\nThe file 'WallDemo.DVB was not found in your search path."
    )
  )
  (princ)
)
(princ "\nWallDemo VBA ver 1.0.0 loaded. by  MICHAEL TINT 2002 misha_t@zahav.co.il \n ")
(princ"Type WALL to run program\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
(princ)
(defun c:wall()
  (setvar "cmdecho" 0) 
(command "_-vbarun" "vbwall"  )(princ)
  )
